export { };

declare global {
    interface Window {
        initializeCharts: () => void;
    }
}
