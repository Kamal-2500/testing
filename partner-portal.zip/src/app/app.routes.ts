import { Routes } from '@angular/router';
import { DashboardComponent, ForgotPasswordComponent, LoginComponent, PartnersComponent, UsersComponent } from './pages';
import { AppLayoutComponent } from './layouts';

export const routes: Routes = [
    {
        path: 'login',
        component: LoginComponent
    },
    {
        path: 'forgot-password',
        component: ForgotPasswordComponent
    },
    {
        path: '',
        redirectTo: 'dashboard',
        pathMatch: 'full'
    },
    {
        path: '',
        component: AppLayoutComponent,
        children: [
            { path: 'dashboard', component: DashboardComponent },
            { path: 'users', component: UsersComponent },
            { path: 'partners', component: PartnersComponent }
        ]
    }
];
