import { Component } from '@angular/core';
import { BodyModifierService } from '../../core/services/body-modifier.service';

@Component({
  selector: 'app-partners',
  standalone: true,
  imports: [],
  templateUrl: './partners.component.html',
  styleUrl: './partners.component.css'
})
export class PartnersComponent {
}
