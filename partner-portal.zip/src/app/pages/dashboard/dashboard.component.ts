import { Component, OnInit, ViewEncapsulation, OnDestroy } from '@angular/core';
import { HeaderComponent, DrawerComponent, FooterComponent } from '../../shared/components';
import { ScriptLoaderService } from '../../core/services/script-loader.service';
import { RouterOutlet } from '@angular/router';
import { BodyModifierService } from '../../core/services/body-modifier.service';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css',
  encapsulation: ViewEncapsulation.None
})
export class DashboardComponent implements OnInit, OnDestroy {

  private scripts = [
    { src: '/assets/vendors/js/charts/apexcharts.min.js' },
    { src: '/assets/vendors/js/extensions/swiper.min.js' },
    { src: '/assets/js/scripts/pages/dashboard-ecommerce.js', callback: this.dashboardEcommerceScriptCallback }
  ];

  constructor(private scriptLoderService: ScriptLoaderService) { }

  ngOnDestroy(): void {
    this.scripts.forEach((script) => {
      this.scriptLoderService.unloadScript(script.src);
    });
    // this.bodyModifierService.removeClasses(this.classes);
    // this.bodyModifierService.removeAttributes(Object.keys(this.attributes));
  }

  ngOnInit(): void {
    this.loadScripts();
    // this.bodyModifierService.addClasses(this.classes);
    // this.bodyModifierService.addAttributes(this.attributes);
  }

  private loadScripts(): void {
    this.scripts.forEach((script) => {
      try {
        this.scriptLoderService.loadScript(script.src, script.callback);
      } catch (error) {
        console.error(error);
      }
    });
  }

  private dashboardEcommerceScriptCallback() {
    if (typeof window.initializeCharts === 'function') {
      window.initializeCharts();
    } else {
      console.error('Initialize charts is not defined');
    }
  }
}