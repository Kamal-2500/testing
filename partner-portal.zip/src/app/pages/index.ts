export * from "./dashboard/dashboard.component";
export * from "./forgot-password/forgot-password.component";
export * from "./login/login.component";
export * from "./partners/partners.component";
export * from "./users/users.component";