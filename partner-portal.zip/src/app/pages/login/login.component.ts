import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, RouterLink } from '@angular/router';
import { BodyModifierService } from '../../core/services/body-modifier.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [RouterLink, ReactiveFormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  loginForm: FormGroup;

  constructor(private formBuilder: FormBuilder, private router: Router, private bodyModifier: BodyModifierService) {
    this.loginForm = this.formBuilder.group({
      emailAddress: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]],
    })
  }

  get emailAddress() {
    return this.loginForm.get('emailAddress');
  }

  get password() {
    return this.loginForm.get('password');
  }

  onLoginSubmit() {
    if (this.emailAddress?.value.trim() === 'test@gmail.com' && this.password?.value.trim() === 'test123') {
      window.location.href = '/dashboard';
    } else {
      this.emailAddress?.setErrors({ 'invalidCredentials': true });
      this.password?.setErrors({ 'invalidCredentials': true });
    }
  }
}