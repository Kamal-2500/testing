import { Component, OnDestroy, OnInit } from '@angular/core';
import { BodyModifierService } from '../../core/services/body-modifier.service';

@Component({
  selector: 'app-users',
  standalone: true,
  imports: [],
  templateUrl: './users.component.html',
  styleUrl: './users.component.css'
})
export class UsersComponent {

}
