import { Injectable, Renderer2, RendererFactory2 } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BodyModifierService {

  private renderer: Renderer2;

  constructor(rendererFactory: RendererFactory2) {
    this.renderer = rendererFactory.createRenderer(null, null);
  }

  addClasses(classes: string[]): void {
    const body = document.body;
    classes.forEach((className) => {
      this.renderer.addClass(body, className);
    });
  }

  removeClasses(classes: string[]): void {
    const body = document.body;
    classes.forEach((className) => {
      this.renderer.removeClass(body, className);
    });
  }

  addAttributes(attributes: { [key: string]: string }): void {
    const body = document.body;
    Object.keys(attributes).forEach((attribute) => {
      this.renderer.setAttribute(body, attribute, attributes[attribute]);
    });
  }

  removeAttributes(attributes: string[]): void {
    const body = document.body;
    attributes.forEach((attribute) => {
      this.renderer.removeAttribute(body, attribute);
    });
  }
}
