import { DOCUMENT } from '@angular/common';
import { Inject, Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ScriptLoaderService {

  constructor(@Inject(DOCUMENT) private document: Document) { }

  loadScript(url: string, callback?: () => void): void {
    const existingScript = this.document.getElementById(url);
    if (existingScript) {
      callback && callback();
      return;
    }

    const script = this.document.createElement('script');
    script.id = url;
    script.src = url;
    script.type = 'text/javascript';
    script.defer = true;
    script.async = false;
    script.onload = () => {
      callback && callback();
      return;
    };
    script.onerror = (error: any) => {
      throw new Error(`Error loading script: ${url}`, error)
    };

    this.document.body.appendChild(script);
  }

  unloadScript(url: string): void {
    const script = this.document.getElementById(url);
    if (script) {
      this.document.body.removeChild(script);
    }
  }
}