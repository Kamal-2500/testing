import { Component, OnDestroy, OnInit, } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ScriptLoaderService } from '../../../core/services/script-loader.service';

@Component({
  selector: 'app-drawer',
  standalone: true,
  imports: [RouterLink],
  templateUrl: './drawer.component.html',
  styleUrl: './drawer.component.css'
})
export class DrawerComponent implements OnInit, OnDestroy {

  private scripts = [
    { src: '/assets/fonts/LivIconsEvo/js/LivIconsEvo.tools.js' },
    { src: '/assets/fonts/LivIconsEvo/js/LivIconsEvo.defaults.js' },
    { src: '/assets/fonts/LivIconsEvo/js/LivIconsEvo.min.js' },
    { src: '/assets/js/scripts/configs/vertical-menu-light.js' },
    { src: '/assets/js/core/app-menu.js' },
    { src: '/assets/js/core/app.js' },
  ];

  constructor(private scriptLoderService: ScriptLoaderService) { }

  ngOnInit(): void {
    this.loadScripts();
  }

  ngOnDestroy(): void {
    this.scripts.forEach((script) => {
      this.scriptLoderService.unloadScript(script.src);
    });
  }


  private loadScripts(): void {
    this.scripts.forEach((script) => {
      try {
        this.scriptLoderService.loadScript(script.src);
      } catch (error) {
        console.error(error);
      }
    });
  }
}