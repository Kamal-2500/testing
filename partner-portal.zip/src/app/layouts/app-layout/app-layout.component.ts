import { Component, OnDestroy, OnInit } from '@angular/core';
import { DrawerComponent, FooterComponent, HeaderComponent } from '../../shared/components';
import { RouterOutlet } from '@angular/router';
import { BodyModifierService } from '../../core/services/body-modifier.service';

@Component({
  selector: 'app-app-layout',
  standalone: true,
  imports: [HeaderComponent, FooterComponent, DrawerComponent, RouterOutlet],
  templateUrl: './app-layout.component.html',
  styleUrl: './app-layout.component.css'
})
export class AppLayoutComponent implements OnInit, OnDestroy {

  constructor(private bodyModifierService: BodyModifierService) { }

  ngOnInit(): void {
    this.bodyModifierService.removeClasses(['1-column', 'bg-full-screen-image', 'blank-page']);
    this.bodyModifierService.addClasses(['2-columns']);
    this.bodyModifierService.addAttributes({ 'data-col': '2-columns' })
  }

  ngOnDestroy(): void {
    this.bodyModifierService.removeClasses(['2-columns']);
  }
}
